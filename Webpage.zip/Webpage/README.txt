*****Welcome to Web Systems and Technologies Notes Page!*****

In order to access the page select the index.html file.

A webpage will load and in the menu bar there are 3 Options
Introduction 
- Contains the introduction of the page. Information about HTTP and HTML can be
read. This is the current page you are in and serves as the homepage

Commands
- Contains information on each commands available for HTTP and HTML. Each commands
have definitions and additional information. 

Status Codes
- Contains a list of the different status codes and the meaning of each one.

****More notes to be added soon****
***Group 1 � Web Systems and Technologies 2018***